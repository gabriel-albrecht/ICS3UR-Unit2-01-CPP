// Copyright (c) 2020 St. Mother Teresa HS All Rights Reserved.
//
// Created by Gabriel A
// Created on Nov 2020
// This program calculates the area and perimeter of a circle with a 12m radius

#include <iostream>
#include <cmath>

int main() {
    std::cout << "If a circle has a 12m radius:" << std::endl;
    std::cout << "" << std::endl;
    std::cout << "Area is " << (M_PI*pow(12.0, 2.0)) << "m" << std::endl;
    std::cout << "Perimeter is " << (2*M_PI*12) << "m" << std::endl;
}
